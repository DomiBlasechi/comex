public class Produtos {
    public static void main(String[] args) {
        System.out.println("_____________________________");
        System.out.println("Seja bem-vindo ao COMEX!");
        System.out.println("_____________________________");
        String produto1 = "Livro infantil";
        String produto2 = "Livro de romance";
        String produto3 = "Livro de ficção científica";
        double valor1 = 19.95;
        double valor2 = 29.80;
        double valor3 = 45.50;

        System.out.println("\nLista de produtos");
        System.out.println("___________________________");
        System.out.println("\nProduto:" + produto1);
        System.out.println("Preço:" + valor1);
        System.out.println("\n***************************");
        System.out.println("\nProduto:" + produto2);
        System.out.println("Preço:" + valor2);
        System.out.println("\n***************************");
        System.out.println("\nProduto:" + produto3);
        System.out.println("Preço:" + valor3);
        System.out.println("\n***************************");

    }
}
