import java.util.Scanner;

public class Clientes {
    public static void main(String[] args) {
        // menu do terminal
        String menu = """
                _____________________________
                Seja bem-vindo ao COMEX!
                _____________________________
        """;

        System.out.println(menu);

        // dados dos clientes
        String cliente1 = "João da Silva";
        String cliente2 = "Maria Aparecida Moreira";
        String cliente3 = "Heitor da Costa";
        String cliente4 = "Lourdes Ferreira";

        int dataDeNascimento1 = 1980;
        int dataDeNascimento2 = 1995;
        int dataDeNascimento3 = 2008;
        int dataDeNascimento4 = 1960;

        int idade1 = 2024 - dataDeNascimento1;
        int idade2 = 2024 - dataDeNascimento2;
        int idade3 = 2024 - dataDeNascimento3;
        int idade4 = 2024 - dataDeNascimento4;

        // dados dos produtos
        String produto1 = "Livro infantil";
        String produto2 = "Livro de romance";
        String produto3 = "Livro de ficção científica";

        double valor1 = 19.95;
        double valor2 = 29.80;
        double valor3 = 45.50;


        // exibição dos dados dos clientes
        String clientes = """
                ______________________________________
                LISTA DE CLIENTES
                ______________________________________
                """;

        System.out.println(clientes);
        System.out.println("\nNome do cliente:" + cliente1);
        System.out.println("Data de nascimento:" + dataDeNascimento1);
        System.out.println("Idade do cliente:" + idade1);
        if (idade1 <= 17){
            System.out.println("Característica etária: adolescente");
        }
        if (idade1 >= 18 && idade1 <= 29){
            System.out.println("Característica etária: jovem");
        }
        if (idade1 >= 30 && idade1 <= 59){
            System.out.println("Característica etária: adulto");
        }
        if (idade1 >= 60){
            System.out.println("Característica etária: idoso");
        }

        System.out.println("\n****************************");
        System.out.println("\nNome do cliente:" + cliente2);
        System.out.println("Data de Nascimento:" + dataDeNascimento2);
        System.out.println("Idade do cliente:" + idade2);
        if (idade2 <= 17){
            System.out.println("Característica etária: adolescente");
        }
        if (idade2 >= 18 && idade2 <= 29){
            System.out.println("Característica etária: jovem");
        }
        if (idade2 >= 30 && idade2 <= 59){
            System.out.println("Característica etária: adulto");
        }
        if (idade2 >= 60){
            System.out.println("Característica etária: idoso");
        }

        System.out.println("\n****************************");
        System.out.println("\nNome do cliente:" + cliente3);
        System.out.println("Data de Nascimento:" + dataDeNascimento3);
        System.out.println("Idade do cliente:" + idade3);
        if (idade3 <= 17){
            System.out.println("Característica etária: adolescente");
        }
        if (idade3 >= 18 && idade3 <= 29){
            System.out.println("Característica etária: jovem");
        }
        if (idade3 >= 30 && idade3 <= 59){
            System.out.println("Característica etária: adulto");
        }
        if (idade3 >= 60){
            System.out.println("Característica etária: idoso");
        }

        System.out.println("\n****************************");
        System.out.println("\nNome do cliente:" + cliente4);
        System.out.println("Data de Nascimento:" + dataDeNascimento4);
        System.out.println("Idade do cliente:" + idade4);
        if (idade4 <= 17){
            System.out.println("Característica etária: adolescente");
        }
        if (idade4 >= 18 && idade4 <= 29){
            System.out.println("Característica etária: jovem");
        }
        if (idade4 >= 30 && idade4 <= 59){
            System.out.println("Característica etária: adulto");
        }
        if (idade4 >= 60){
            System.out.println("Característica etária: idoso");
        }

        System.out.println("\n****************************");

        String produtos = """
            --------------------------------------------
            LISTA DE PRODUTOS
            --------------------------------------------
            
            """;
        System.out.println(produtos);

        System.out.println("\nProduto:" + produto1);
        System.out.println("Valor:" + valor1);
        System.out.println("\n****************************");
        System.out.println("\nProduto:" + produto2);
        System.out.println("Valor:" + valor2);
        System.out.println("\nProduto:" + produto3);
        System.out.println("Valor:" + valor3);
        System.out.println("\n****************************");
    }


}
