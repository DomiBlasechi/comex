public class Main {
    public static void main(String[] args) {
        System.out.println("_____________________________");
        System.out.println("Seja bem-vindo ao COMEX!");
        System.out.println("_____________________________");
        String cliente1 = "João da Silva";
        String cliente2 = "Maria Aparecida Moreira";
        int dataDeNascimento1 = 1980;
        int dataDeNascimento2 = 1975;

        System.out.println("\nNome do cliente:" + cliente1);
        System.out.println("Data de nascimento:" + dataDeNascimento1);
        System.out.println("\n****************************");
        System.out.println("\nNome do cliente:" + cliente2);
        System.out.println("Data de Nascimento:" + dataDeNascimento2);


    }
}